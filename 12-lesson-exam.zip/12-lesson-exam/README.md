# Makon frontend

React + Vite + Tailwind CSS asosidagi uch sahifali interfeys:

- `/` — bosh sahifa
- `/login` — kirish sahifasi
- `/register` — ro‘yxatdan o‘tish sahifasi

Kirish va ro‘yxatdan o‘tish formalari `backend/` ichidagi Node.js API bilan ulangan. Muvaffaqiyatli autentifikatsiyadan keyin foydalanuvchi bosh sahifaga qaytadi; sessiya brauzerda saqlanadi va sahifa qayta ochilganda API orqali tekshiriladi. Bosh sahifadagi profil menyusidan tizimdan chiqish mumkin.

Development rejimida Vite `/api` so‘rovlarini `http://localhost:3001` ga yo‘naltiradi. Shuning uchun frontend va backendni alohida terminallarda ishga tushiring:

Dizayn asosan komponentlardagi Tailwind utility classlari bilan yozilgan. `src/styles.css` faylida Tailwind importi, rang va shrift tokenlari hamda qisqa global sozlamalar bor.

## Ishga tushirish

```bash
npm install
npm run dev
```

```bash
cd backend
npm install
npm run dev
```

Production buildni tekshirish:

```bash
npm run build
```

Backendni ishga tushirish va API tavsifi uchun [backend/README.md](backend/README.md) fayliga qarang.
