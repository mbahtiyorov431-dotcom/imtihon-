const apiBaseUrl = (import.meta.env.VITE_API_URL || "/api").replace(/\/+$/, "");
export const authTokenKey = "makon.auth.token";

export async function apiRequest(path, options = {}) {
  const headers = new Headers(options.headers);
  const token = window.localStorage.getItem(authTokenKey);

  if (options.body && !headers.has("Content-Type")) {
    headers.set("Content-Type", "application/json");
  }
  if (token && !headers.has("Authorization")) {
    headers.set("Authorization", `Bearer ${token}`);
  }

  const response = await fetch(`${apiBaseUrl}/${path.replace(/^\/+/, "")}`, {
    ...options,
    headers,
  });
  const data = await response.json().catch(() => ({}));

  if (!response.ok) {
    throw new Error(data.message || "So‘rovni bajarib bo‘lmadi.");
  }

  return data;
}
