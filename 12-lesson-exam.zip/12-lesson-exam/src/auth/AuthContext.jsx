import {
  createContext,
  useCallback,
  useContext,
  useEffect,
  useMemo,
  useState,
} from "react";
import { apiRequest, authTokenKey } from "./api.js";

const AuthContext = createContext(null);

export function AuthProvider({ children }) {
  const [user, setUser] = useState(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    let active = true;
    const token = window.localStorage.getItem(authTokenKey);

    if (!token) {
      setLoading(false);
      return () => {
        active = false;
      };
    }

    apiRequest("auth/me")
      .then(({ user: currentUser }) => {
        if (active) setUser(currentUser);
      })
      .catch(() => {
        window.localStorage.removeItem(authTokenKey);
        if (active) setUser(null);
      })
      .finally(() => {
        if (active) setLoading(false);
      });

    return () => {
      active = false;
    };
  }, []);

  const authenticate = useCallback(async (path, credentials) => {
    const result = await apiRequest(path, {
      method: "POST",
      body: JSON.stringify(credentials),
    });
    window.localStorage.setItem(authTokenKey, result.token);
    setUser(result.user);
    return result.user;
  }, []);

  const register = useCallback(
    (credentials) => authenticate("auth/register", credentials),
    [authenticate],
  );
  const login = useCallback(
    (credentials) => authenticate("auth/login", credentials),
    [authenticate],
  );
  const logout = useCallback(async () => {
    try {
      await apiRequest("auth/logout", { method: "POST" });
    } catch {
      // Clear the local session even if the server cannot be reached.
    } finally {
      window.localStorage.removeItem(authTokenKey);
      setUser(null);
    }
  }, []);

  const value = useMemo(
    () => ({ user, loading, login, register, logout }),
    [user, loading, login, register, logout],
  );

  return <AuthContext.Provider value={value}>{children}</AuthContext.Provider>;
}

export function useAuth() {
  const context = useContext(AuthContext);
  if (!context)
    throw new Error("useAuth AuthProvider ichida ishlatilishi kerak.");
  return context;
}
